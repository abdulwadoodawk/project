﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectAPI.DI;
using ProjectAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PolicyController : ControllerBase
    {
        private readonly IPolicy policy = null;
        public PolicyController(IPolicy policy)
        {
            this.policy = policy;
        }
        [HttpGet]
        public async Task<IActionResult> ShowAllPolicy()
        {
            var policies = await policy.ShowAllPolicy();
            return Ok(policies);
        }
        [HttpPost]
        public async Task<IActionResult> CreatePolicy([FromBody] PolicyRegistrationModel policymodel)
        {
            string a = await policy.RegisterPolicy(policymodel);
            return Ok(a);
        }
        [HttpPut]
        public async Task<IActionResult> UpdatePolicy(int policyid, PolicyRegistrationModel policyRegistrationModel)
        {
            int a = await policy.UpdatePolicy(policyid, policyRegistrationModel);
            return Ok(a);
        }
        [HttpDelete]
        public async Task<IActionResult> DeletePolicy(int policyid)
        {
            int a = await policy.DeletePolicy(policyid);
            return Ok(a);
        }
    }
}
