﻿using Microsoft.EntityFrameworkCore;
using ProjectAPI.DataAccessLayer;
using ProjectAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAPI.DI
{
    public class PolicyRepository : IPolicy
    {
        public readonly PMSDbContext dbContext = null;
        public PolicyRepository(PMSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<List<PolicyRegistrationModel>> ShowAllPolicy()
        {
            var ar = await dbContext.policyRegistrationModels.ToListAsync();
            return ar;
        }
        public async Task<string> RegisterPolicy(PolicyRegistrationModel policyRegistrationModel)
        {
            dbContext.policyRegistrationModels.Add(policyRegistrationModel);
            await dbContext.SaveChangesAsync();
            return policyRegistrationModel.PolicyName;
        }
        public async Task<int> UpdatePolicy(int policyid, PolicyRegistrationModel policyRegistrationModel)
        {
            var ar = await dbContext.policyRegistrationModels.Where(x => x.PolicyId == policyid).FirstOrDefaultAsync();
            if (ar != null)
            {
                ar.PolicyName = policyRegistrationModel.PolicyName;
                ar.StartDate = policyRegistrationModel.StartDate;
                ar.Duration = policyRegistrationModel.Duration;
                ar.CompanyName = policyRegistrationModel.CompanyName;
                ar.InitialDeposit = policyRegistrationModel.InitialDeposit;
                ar.PolicyType = policyRegistrationModel.PolicyType;
                ar.UserTypes = policyRegistrationModel.UserTypes;
                ar.Term = policyRegistrationModel.Term;
                ar.TermAmount = policyRegistrationModel.TermAmount;
                ar.Interest = policyRegistrationModel.Interest;
            }
            await dbContext.SaveChangesAsync();
            return policyid;
        }
        public async Task<int> DeletePolicy(int policyid)
        {
            var ar = await dbContext.policyRegistrationModels.Where(x => x.PolicyId == policyid).FirstOrDefaultAsync();
            if(ar!=null)
            {
                dbContext.policyRegistrationModels.Remove(ar);
            }
            await dbContext.SaveChangesAsync();
            return policyid;
        }
    }
}
