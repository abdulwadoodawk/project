﻿using Microsoft.EntityFrameworkCore;
using ProjectAPI.DataAccessLayer;
using ProjectAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAPI.DI
{
    public class AdminRepository : IAdmin
    {
        public readonly PMSDbContext dbContext = null;
        public AdminRepository(PMSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<string> AdminRegister(AdminModel adminModel)
        {
            dbContext.adminModels.Add(adminModel);
            await dbContext.SaveChangesAsync();
            return adminModel.Email;
        }
        public async Task<string> DeleteAdmin(string emailid)
        {
            var ar = await dbContext.adminModels.Where(x => x.Email == emailid).FirstOrDefaultAsync();
            if (ar != null)
            {
                dbContext.adminModels.Remove(ar);
            }
            await dbContext.SaveChangesAsync();
            return emailid;
        }
        public async Task<string> UpdateAdmin(string emailid, AdminModel adminModel)
        {
            var ar = await dbContext.adminModels.Where(x => x.Email == emailid).FirstOrDefaultAsync();
            if (ar != null)
            {
                ar.Password = adminModel.Password;
                ar.ConfirmPass = adminModel.ConfirmPass;
            }
            await dbContext.SaveChangesAsync();
            return emailid;
        }
    }
    
}
