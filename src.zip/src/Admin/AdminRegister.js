import React, { Component } from 'react';
import Header from '../Common/Header';
import '../Admin/Admin.css';

export default class AdminRegister extends Component {
  render() {
    return (
      <><header>
<Header></Header>
      </header><div>

          {/* <div class="tab-pane fade" id="pills-register" role="tabpanel" aria-labelledby="tab-register"> */}
            <form>
              <div class="text-center mb-3">
                <hr></hr>
                <h3>Register Here:</h3>
              </div>
              
              <div class="form-outline mb-4">
              <label class="form-label" for="registerName">Email</label>
                <input type="email" id="registerName" class="form-control" />
                
              </div>

              <div class="form-outline mb-4">
              <label class="form-label" for="registerRepeatPassword">Password</label>
                <input type="password" id="registerRepeatPassword" class="form-control" />
                
              </div>
              <div class="form-outline mb-4">
              <label class="form-label" for="registerRepeatPassword">Confirm Password</label>
                <input type="password" id="registerRepeatPassword" class="form-control" />
                
              </div>

              <br></br>

              <button type="submit" class="btn btn-primary btn-block mb-3">Register</button>
            </form>
          </div>
        {/* </div> */}
        </>
    )
  }
}
