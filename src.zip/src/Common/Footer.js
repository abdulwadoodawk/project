import React, { Component } from 'react'
import '../Common/Footer.css'
export default class Footer extends Component {
  render() {
    return (
      
        <footer className='footer'>

            <p>Copyright @ Hexaware.com. All rights resrved.</p>
        </footer>

      
    )
  }
}
