import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes,Route,Link } from 'react-router-dom';
import AdminLogin from './Admin/AdminLogin';
import AdminRegister from './Admin/AdminRegister';
import UserLogin from './User/UserLogin';
import UserRegister from './User/UserRegister';
import ShowPolicy from './Policy/ShowPolicy';
function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Link to="/"></Link>
      <Link to="/ShowPolicy">ShowAllPolicy</Link>
      <Link to="/UserRegister">UserRegister</Link>
      <Link to="/UserLogin">UserLogin</Link>
      <Link to="/AdminRegister">AdminRegister</Link>
      <Link to="/AdminLogin">AdminLogin</Link>
      <Link to="/RegisterPolicy">RegisterPolicy</Link>
      </BrowserRouter>
      {/* <AdminLogin></AdminLogin> */}
      {/* <AdminRegister></AdminRegister> */}
      {/* <UserLogin></UserLogin> */}
      <UserRegister></UserRegister>
      {/* <ShowPolicy></ShowPolicy> */}
    </div>
  );
}

export default App;
